ManifestAmbiguity
=================

Parser and Modify AndroidManifest.xml to prevent APK from re-packege

1 make, then get an executable file manifestAmbiguity.


2 ./manifestAmbiguity, then you will get complete information of this project.
