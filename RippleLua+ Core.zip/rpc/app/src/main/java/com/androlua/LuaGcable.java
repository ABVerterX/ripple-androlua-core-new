package com.androlua;

public interface LuaGcable
{
	public void gc();
	public boolean isGc();
}
