appname="AndroLua+"
appver="1.0"
app_key="4yCilmN24RCRG82uc93kSZ1F"
app_channel="qq group"
packagename="com.androlua"
user_permission={
  "INTERNET",
  "WRITE_EXTERNAL_STORAGE",
}
